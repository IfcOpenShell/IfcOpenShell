from os.path import dirname
from os.path import realpath


package_path = dirname(realpath(__file__))
