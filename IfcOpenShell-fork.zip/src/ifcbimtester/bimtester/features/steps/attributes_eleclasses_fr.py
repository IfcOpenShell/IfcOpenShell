from behave import step

import attributes_eleclasses_methods as aem
from utils import switch_locale


the_lang = "fr"


"""
# TODO the next line needs translation
@step("There are no {ifc_class} elements")
def step_impl(context, ifc_class):
    switch_locale(context.localedir, the_lang)
    aem.no_eleclass(
        context,
        ifc_class
    )


# TODO the next line needs translation
@step("There are no {ifc_class} elements because {reason}")
def step_impl(context, ifc_class, reason):
    switch_locale(context.localedir, the_lang)
    aem.no_eleclass(
        context,
        ifc_class
    )


# TODO the next line needs translation
@step("All {ifc_class} elements class attributes have a value")
def step_impl(context, ifc_class):
    switch_locale(context.localedir, the_lang)
    aem.eleclass_have_class_attributes_with_a_value(
        context,
        ifc_class
    )


# TODO the next line needs translation
@step("All {ifc_class} elements have a name given")
def step_impl(context, ifc_class):
    switch_locale(context.localedir, the_lang)
    aem.eleclass_has_name_with_a_value(
        context,
        ifc_class
    )


# TODO the next line needs translation
@step("All {ifc_class} elements have a description given")
def step_impl(context, ifc_class):
    switch_locale(context.localedir, the_lang)
    aem.eleclass_has_description_with_a_value(
        context,
        ifc_class
    )
"""
