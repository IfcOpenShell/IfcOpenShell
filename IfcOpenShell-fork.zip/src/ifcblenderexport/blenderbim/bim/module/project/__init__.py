import bpy
from . import ui, operator

classes = (
    operator.CreateProject,
    operator.ValidateIfcFile,
    ui.BIM_PT_project,
)


def register():
    pass


def unregister():
    pass
