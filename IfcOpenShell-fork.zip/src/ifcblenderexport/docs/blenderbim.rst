BlenderBIM
==========

BlenderBIM is an add-on to Blender that turns Blender into a powerful BIM
authoring program, supporting IFC import, export, and data manipulation.

This documentation is free software! You are free to contribute and help write
this document.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   blenderbim/installation
   blenderbim/scene


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
