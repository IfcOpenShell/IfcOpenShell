﻿#ifndef SHAPES
#define SHAPES(T)
#endif
#ifndef SHAPE
#define SHAPE(T)
#endif
#ifndef WIRE
#define WIRE(T)
#endif
#ifndef FACE
#define FACE(T)
#endif
#ifndef CURVE
#define CURVE(T)
#endif
#ifndef CLASS
#define CLASS(T,V)
#endif