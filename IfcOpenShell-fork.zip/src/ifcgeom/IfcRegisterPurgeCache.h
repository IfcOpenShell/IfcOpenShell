﻿#include "IfcRegisterUndef.h"
#define CLASS(T,V) \
	T.clear();
#include "IfcRegisterDef.h"

#include "IfcRegister.h"